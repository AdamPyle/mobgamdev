﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class testScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("Hello world!");
        Debug.Log("Edited from the Browser in GitHub!");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
